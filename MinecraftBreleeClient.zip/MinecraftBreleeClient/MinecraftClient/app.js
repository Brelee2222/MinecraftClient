const fsLibrary = require("fs");

fsLibrary.appendFileSync(process.env.APPDATA + "\\.minecraft\\resourcepacks\\BreleeTextures.zip", fsLibrary.readFileSync("./BreleeTextures.zip"))

var optionsFile = fsLibrary.readFileSync(process.env.APPDATA + "\\.minecraft\\options.txt", {encoding:'utf8', flag:'r'});

const timeSig = new Date();

if(!fsLibrary.existsSync(process.env.APPDATA + "\\.minecraft\\optionSaves\\"))
    fsLibrary.mkdirSync(process.env.APPDATA + "\\.minecraft\\optionSaves\\");

fsLibrary.appendFileSync(process.env.APPDATA + "\\.minecraft\\optionSaves\\options" + String(timeSig.getTime()) + ".txt", optionsFile)

optionsFile = optionsFile.split("\n")

var options = {};

const keyKeys = [];

const keyValues = [];

for(i in optionsFile) {
    l = optionsFile[i].replace("\r", "").split(":");
    if(l[0].startsWith("key_key.")) {
        keyKeys.push(l[0])
        keyValues.push(l[1])
    } else
        options[l[0]] = l[1];
}

for(i in keyValues) {
    switchValue = keyValues[i];
    switchWith = Math.floor(Math.random()*keyValues.length);
    keyValues[i] = keyValues[switchWith];
    keyValues[switchWith] = switchValue;
}

for(i in keyValues) {
    options[keyKeys[i]] = keyValues[i];
}

options.autoJump = !!Math.floor(Math.random*2)
options.gamma = "-100.0"
options.darkMojangStudiosBackground = "true";
options.autoJump = "true";
options.toggleCrouch = "true";
options.toggleSprint = "true";
options.fov = "2.0";
options.narrator = "1";
options.mainHand = "left";
options.lang = "br_lt";
options.resourcePacks = '["vanilla","file/BreleeTextures.zip"]';

var newOptions = JSON.stringify(options).replaceAll("\",\"", "\n").replace("{", "").replace("}", "").replaceAll("\":\"", ":").replace('"', "").replaceAll("\\\"", '"');

newOptions = newOptions.substring(0, newOptions.length-1)


fsLibrary.writeFileSync(process.env.APPDATA + "\\.minecraft\\options.txt", newOptions);

console.log(newOptions);